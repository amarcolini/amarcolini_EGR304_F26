# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.cmf"
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.hex"
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.hxl"
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.mum"
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.o"
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.sdb"
  "/home/alessandro/MPLABProjects/BloodPressure/out/BloodPressure/default.sym"
  )
endif()
