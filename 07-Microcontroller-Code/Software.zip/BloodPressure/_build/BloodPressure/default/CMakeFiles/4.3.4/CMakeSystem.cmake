set(CMAKE_HOST_SYSTEM "Linux-7.1.3-1-default")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.1.3-1-default")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/alessandro/MPLABProjects/BloodPressure/cmake/BloodPressure/default/.generated/toolchain.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
