/*
 * Project: EGR 304 Blood Pressure Sensor and Display (Team 204)
 * MCU:     PIC18F57Q43 (Curiosity Nano) — MCC Melody Version
 * Actuators:
 *   - PUMP  -> PWM3S1P1_OUT (RB0) : ZR370-02PM (4.5V [4.0-5.0V] or 6.0V
 * [5.2-6.5V])
 *   - VALVE -> PWM3S1P2_OUT (RB3) : FA0520E (6.0V rated, 5.0-6.0V operating)
 * Contrast:
 *   - VO    -> PWM2S1P1_OUT (RD6) -> R15 (10k) + C14 (1uF) -> U6.VO
 * Telemetry:
 *   - UART1 TX over Curiosity Nano CDC bridge (non-blocking RAM buffer dumped
 * at end of run)
 */

#include "mcc_generated_files/system/system.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

// ============================================================================
// DATASHEET VOLTAGE LIMITS & SUPPLY PARAMETERS (in millivolts)
// ============================================================================
#define VIN_MV 9000UL         // Barrel jack supply (e.g., 9000 mV = 9.0V)
#define BRIDGE_DROP_MV 1100UL // FAN8100N (U3) typical voltage drop

// Pump (ZR370-02PM): set to 4500 (4.0-5.0V range) or 6000 (5.2-6.5V range)
#define PUMP_RATED_MV 4500UL
#define PUMP_TARGET_MV 4500UL

// Valve (FA0520E): 6000 mV rated (5000..6000 mV operating range)
#define VALVE_RATED_MV 6000UL
#define VALVE_TARGET_MV                                                        \
  5500UL // ~5.5V keeps valve actuated safely in 5.0-6.0V range

// ============================================================================
// PRESSURE CALIBRATION, TIMING & TELEMETRY LIMITS
// ============================================================================
#define COUNTS_PER_MMHG_X100 195UL // Tune with reference gauge at TP5
#define TARGET_INFLATE_MMHG 170U
#define MAX_SAFETY_MMHG 210U
#define MIN_DEFLATE_MMHG 45U
#define INFLATE_TIMEOUT_MS 20000U
#define SAMPLE_PERIOD_MS 10U // 100 Hz

#define SYS_RATIO_PCT 55U
#define DIA_RATIO_PCT 80U
#define MAX_BEATS 120U
#define TELEM_MAX_SAMPLES 450U // 450 * 10 ms = 4.5 s of buffered waveform data

// ============================================================================
// TYPES & STATE
// ============================================================================
typedef enum {
  STATE_IDLE = 0,
  STATE_ZERO_CAL,
  STATE_INFLATE,
  STATE_DEFLATE_MEASURE,
  STATE_VENT_DONE,
  STATE_FAULT
} bp_state_t;

typedef struct {
  uint16_t cuff_mmhg;
  uint16_t pulse_amp;
  uint16_t tick;
} beat_sample_t;

typedef struct {
  uint16_t tick;
  uint16_t cuff_mmhg;
  uint16_t raw_p;
  uint16_t raw_ac;
  uint16_t amp;
  uint8_t pump_d;
  uint8_t valve_d;
} telem_sample_t;

static beat_sample_t beat_log[MAX_BEATS];
static telem_sample_t telem_buf[TELEM_MAX_SAMPLES];

static uint8_t beat_count = 0;
static uint16_t telem_idx = 0;
static uint16_t adc_zero_offset = 0;
static uint8_t contrast_duty = 12;
static uint16_t last_sys = 0, last_dia = 0, last_map = 0, last_bpm = 0;

// ============================================================================
// UART1 RETARGET & TELEMETRY HELPERS
// ============================================================================
static void telem_reset(void) { telem_idx = 0; }

static void telem_record(uint16_t tick, uint16_t cuff_mmhg, uint16_t raw_p,
                         uint16_t raw_ac, uint16_t amp, uint8_t pump_d,
                         uint8_t valve_d) {
  if (telem_idx < TELEM_MAX_SAMPLES) {
    telem_buf[telem_idx].tick = tick;
    telem_buf[telem_idx].cuff_mmhg = cuff_mmhg;
    telem_buf[telem_idx].raw_p = raw_p;
    telem_buf[telem_idx].raw_ac = raw_ac;
    telem_buf[telem_idx].amp = amp;
    telem_buf[telem_idx].pump_d = pump_d;
    telem_buf[telem_idx].valve_d = valve_d;
    telem_idx++;
  }
}

static void telem_dump_csv(void) {
  printf("tick_10ms,cuff_mmhg,raw_pressure_adc,raw_pulse_adc,pulse_amp,pump_"
         "duty,valve_duty\r\n");
  for (uint16_t i = 0; i < telem_idx; i++) {
    const telem_sample_t *s = &telem_buf[i];
    printf("%u,%u,%u,%u,%u,%u,%u\r\n", s->tick, s->cuff_mmhg, s->raw_p,
           s->raw_ac, s->amp, s->pump_d, s->valve_d);
  }
  printf("---END_TELEM---\r\n");
}

// ============================================================================
// PWM3 & PWM2 HARDWARE DUTY HELPERS (Raw Tick Scaling + Datasheet Clamping)
// ============================================================================
static uint16_t pwm3_pct_to_ticks(uint8_t duty_pct) {
  if (duty_pct > 100U)
    duty_pct = 100U;
  uint32_t period_ticks = (uint32_t)(((uint16_t)PWM3PRH << 8) | PWM3PRL) + 1UL;
  return (uint16_t)((period_ticks * duty_pct) / 100UL);
}

static uint16_t pwm2_pct_to_ticks(uint8_t duty_pct) {
  if (duty_pct > 100U)
    duty_pct = 100U;
  uint32_t period_ticks = (uint32_t)(((uint16_t)PWM2PRH << 8) | PWM2PRL) + 1UL;
  return (uint16_t)((period_ticks * duty_pct) / 100UL);
}

static uint8_t voltage_to_pwm_duty(uint32_t target_mv,
                                   uint32_t max_allowed_mv) {
  uint32_t safe_target_mv =
      (target_mv > max_allowed_mv) ? max_allowed_mv : target_mv;
  if (VIN_MV <= BRIDGE_DROP_MV) {
    return 0U;
  }
  uint32_t avail_mv = VIN_MV - BRIDGE_DROP_MV;
  uint32_t duty = (safe_target_mv * 100UL) / avail_mv;
  if (duty > 100UL) {
    duty = 100UL;
  }
  return (uint8_t)duty;
}

static void pwm3_apply_outputs(uint8_t pump_duty_pct, uint8_t valve_duty_pct) {
  // PWM3 Output 1 -> RB0 (PUMP)
  PWM3_16BIT_SetSlice1Output1DutyCycleRegister(
      pwm3_pct_to_ticks(pump_duty_pct));
  // PWM3 Output 2 -> RB3 (VALVE)
  PWM3_16BIT_SetSlice1Output2DutyCycleRegister(
      pwm3_pct_to_ticks(valve_duty_pct));
  PWM3_16BIT_LoadBufferRegisters();
}

static void actuators_safe_vent(void) {
  // De-energize both pump and FA0520E valve (common port vents to exhaust)
  pwm3_apply_outputs(0U, 0U);
}

static uint8_t get_pump_run_duty(void) {
  return voltage_to_pwm_duty(PUMP_TARGET_MV, PUMP_RATED_MV);
}

static uint8_t get_valve_hold_duty(void) {
  return voltage_to_pwm_duty(VALVE_TARGET_MV, VALVE_RATED_MV);
}

static void lcd_contrast_set(uint8_t duty_pct) {
  PWM2_16BIT_SetSlice1Output1DutyCycleRegister(pwm2_pct_to_ticks(duty_pct));
  PWM2_16BIT_LoadBufferRegisters();
}

static uint16_t adc_read_avg(adc_channel_t ch, uint8_t samples) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < samples; i++) {
    sum += (uint16_t)ADC_ChannelSelectAndConvert(ch);
  }
  return (uint16_t)(sum / samples);
}

static uint16_t read_cuff_raw_and_mmhg(uint16_t *raw_out) {
  uint16_t raw = adc_read_avg(ADC_CHANNEL_ANC3, 8);
  if (raw_out != NULL) {
    *raw_out = raw;
  }
  if (raw <= adc_zero_offset)
    return 0;
  return (uint16_t)(((uint32_t)(raw - adc_zero_offset) * 100UL) /
                    COUNTS_PER_MMHG_X100);
}

static uint16_t read_cuff_mmhg(void) { return read_cuff_raw_and_mmhg(NULL); }

// ============================================================================
// 16x2 LCD DRIVER (NHD-0216K1Z-FL-YBW, 4-bit Write-Only)
// ============================================================================
static void lcd_write_nibble(uint8_t n) {
  if (n & 0x01) {
    LCD_DB4_SetHigh();
  } else {
    LCD_DB4_SetLow();
  }
  if (n & 0x02) {
    LCD_DB5_SetHigh();
  } else {
    LCD_DB5_SetLow();
  }
  if (n & 0x04) {
    LCD_DB6_SetHigh();
  } else {
    LCD_DB6_SetLow();
  }
  if (n & 0x08) {
    LCD_DB7_SetHigh();
  } else {
    LCD_DB7_SetLow();
  }

  LCD_E_SetHigh();
  __delay_us(2);
  LCD_E_SetLow();
  __delay_us(50);
}

static void lcd_send(uint8_t val, bool is_data) {
  if (is_data) {
    LCD_RS_SetHigh();
  } else {
    LCD_RS_SetLow();
  }
  lcd_write_nibble((val >> 4) & 0x0F);
  lcd_write_nibble(val & 0x0F);
}

static void lcd_cmd(uint8_t cmd) {
  lcd_send(cmd, false);
  if (cmd == 0x01 || cmd == 0x02)
    __delay_ms(2);
}

static void lcd_init(void) {
  __delay_ms(50);
  LCD_RS_SetLow();
  LCD_E_SetLow();

  lcd_write_nibble(0x03);
  __delay_ms(5);
  lcd_write_nibble(0x03);
  __delay_us(150);
  lcd_write_nibble(0x03);
  __delay_us(150);
  lcd_write_nibble(0x02);

  lcd_cmd(0x28);
  lcd_cmd(0x0C);
  lcd_cmd(0x06);
  lcd_cmd(0x01);
}

static void lcd_print_line(uint8_t row, const char *str) {
  lcd_cmd((row == 0) ? 0x80 : 0xC0);
  uint8_t col = 0;
  while (*str && col < 16) {
    lcd_send((uint8_t)(*str++), true);
    col++;
  }
  while (col++ < 16)
    lcd_send(' ', true);
}

// ============================================================================
// OSCILLOMETRIC BP CALCULATION
// ============================================================================
static bool compute_blood_pressure(void) {
  if (beat_count < 6)
    return false;

  uint8_t max_idx = 0;
  uint16_t max_amp = 0;
  for (uint8_t i = 0; i < beat_count; i++) {
    if (beat_log[i].pulse_amp > max_amp) {
      max_amp = beat_log[i].pulse_amp;
      max_idx = i;
    }
  }
  if (max_amp < 25)
    return false;

  last_map = beat_log[max_idx].cuff_mmhg;

  uint16_t sys_th = (uint16_t)(((uint32_t)max_amp * SYS_RATIO_PCT) / 100UL);
  last_sys = beat_log[0].cuff_mmhg;
  for (int16_t i = (int16_t)max_idx; i >= 0; i--) {
    if (beat_log[i].pulse_amp <= sys_th) {
      last_sys = beat_log[i].cuff_mmhg;
      break;
    }
  }

  uint16_t dia_th = (uint16_t)(((uint32_t)max_amp * DIA_RATIO_PCT) / 100UL);
  last_dia = beat_log[beat_count - 1].cuff_mmhg;
  for (uint8_t i = max_idx; i < beat_count; i++) {
    if (beat_log[i].pulse_amp <= dia_th) {
      last_dia = beat_log[i].cuff_mmhg;
      break;
    }
  }

  uint32_t dt_sum = 0;
  uint8_t dt_cnt = 0;
  for (uint8_t i = 1; i < beat_count; i++) {
    uint16_t dt = beat_log[i].tick - beat_log[i - 1].tick;
    if (dt >= 30 && dt <= 150) {
      dt_sum += dt;
      dt_cnt++;
    }
  }
  last_bpm = (dt_cnt > 0) ? (uint16_t)(6000UL / (dt_sum / dt_cnt)) : 0;
  return true;
}

// ============================================================================
// MAIN LOOP
// ============================================================================
int main(void) {
  char line0[17], line1[17];
  bp_state_t state = STATE_IDLE;
  bool prev_sw1 = false, prev_sw2 = false;

  SYSTEM_Initialize();

  LED_SetHigh();

  const uint8_t pump_duty = get_pump_run_duty();
  const uint8_t valve_duty = get_valve_hold_duty();

  lcd_contrast_set(contrast_duty);
  lcd_init();

  __delay_ms(200);

  lcd_print_line(0, "BP Monitor Ready");
  lcd_print_line(1, "SW1:Start SW2:VO");

  // pwm3_apply_outputs(50, 0);
  int temp = 0;
  while (1) {
    bool sw1_now = (SW1_START_GetValue() == 1);
    bool sw2_now = (SW2_ACTION_GetValue() == 1);
    bool sw1_pressed = (sw1_now && !prev_sw1);
    bool sw2_pressed = (sw2_now && !prev_sw2);
    prev_sw1 = sw1_now;
    prev_sw2 = sw2_now;
    if (sw1_pressed) {
      temp++;
      if (temp > 2) {
        temp = 0;
      };
    }
    if (temp == 0) {
      pwm3_apply_outputs(0, 0);
      LED_SetLow();
    } else if (temp == 1) {
      pwm3_apply_outputs(pump_duty, 0);
      LED_SetLow();
    } else {
      pwm3_apply_outputs(0, 0);
      LED_SetHigh();
    }
    uint16_t p = read_cuff_mmhg();
    printf("p: %u, b1: %d, b2: %d\r\n", p, sw1_now ? 1 : 0, sw2_now ? 1 : 0);
    __delay_ms(50);

    lcd_print_line(0, "BP Monitor Ready");
    lcd_print_line(1, "SW1:Start SW2:VO");
  }
  return 0;
}