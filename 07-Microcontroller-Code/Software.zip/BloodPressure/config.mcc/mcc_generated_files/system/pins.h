/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RB0 aliases
#define PUMP_TRIS                 TRISBbits.TRISB0
#define PUMP_LAT                  LATBbits.LATB0
#define PUMP_PORT                 PORTBbits.RB0
#define PUMP_WPU                  WPUBbits.WPUB0
#define PUMP_OD                   ODCONBbits.ODCB0
#define PUMP_ANS                  ANSELBbits.ANSELB0
#define PUMP_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define PUMP_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define PUMP_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define PUMP_GetValue()           PORTBbits.RB0
#define PUMP_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define PUMP_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define PUMP_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define PUMP_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define PUMP_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define PUMP_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define PUMP_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define PUMP_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define SW1_START_TRIS                 TRISBbits.TRISB1
#define SW1_START_LAT                  LATBbits.LATB1
#define SW1_START_PORT                 PORTBbits.RB1
#define SW1_START_WPU                  WPUBbits.WPUB1
#define SW1_START_OD                   ODCONBbits.ODCB1
#define SW1_START_ANS                  ANSELBbits.ANSELB1
#define SW1_START_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define SW1_START_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define SW1_START_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define SW1_START_GetValue()           PORTBbits.RB1
#define SW1_START_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define SW1_START_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define SW1_START_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define SW1_START_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define SW1_START_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define SW1_START_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define SW1_START_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define SW1_START_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 aliases
#define LED_TRIS                 TRISBbits.TRISB2
#define LED_LAT                  LATBbits.LATB2
#define LED_PORT                 PORTBbits.RB2
#define LED_WPU                  WPUBbits.WPUB2
#define LED_OD                   ODCONBbits.ODCB2
#define LED_ANS                  ANSELBbits.ANSELB2
#define LED_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define LED_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define LED_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define LED_GetValue()           PORTBbits.RB2
#define LED_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define LED_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define LED_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RB3 aliases
#define VALVE_TRIS                 TRISBbits.TRISB3
#define VALVE_LAT                  LATBbits.LATB3
#define VALVE_PORT                 PORTBbits.RB3
#define VALVE_WPU                  WPUBbits.WPUB3
#define VALVE_OD                   ODCONBbits.ODCB3
#define VALVE_ANS                  ANSELBbits.ANSELB3
#define VALVE_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define VALVE_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define VALVE_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define VALVE_GetValue()           PORTBbits.RB3
#define VALVE_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define VALVE_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define VALVE_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define VALVE_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define VALVE_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define VALVE_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define VALVE_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define VALVE_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RB5 aliases
#define LCD_E_TRIS                 TRISBbits.TRISB5
#define LCD_E_LAT                  LATBbits.LATB5
#define LCD_E_PORT                 PORTBbits.RB5
#define LCD_E_WPU                  WPUBbits.WPUB5
#define LCD_E_OD                   ODCONBbits.ODCB5
#define LCD_E_ANS                  ANSELBbits.ANSELB5
#define LCD_E_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define LCD_E_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define LCD_E_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define LCD_E_GetValue()           PORTBbits.RB5
#define LCD_E_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define LCD_E_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define LCD_E_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define LCD_E_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define LCD_E_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define LCD_E_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define LCD_E_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define LCD_E_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RC0 aliases
#define EX_DIG1_TRIS                 TRISCbits.TRISC0
#define EX_DIG1_LAT                  LATCbits.LATC0
#define EX_DIG1_PORT                 PORTCbits.RC0
#define EX_DIG1_WPU                  WPUCbits.WPUC0
#define EX_DIG1_OD                   ODCONCbits.ODCC0
#define EX_DIG1_ANS                  ANSELCbits.ANSELC0
#define EX_DIG1_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define EX_DIG1_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define EX_DIG1_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define EX_DIG1_GetValue()           PORTCbits.RC0
#define EX_DIG1_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define EX_DIG1_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define EX_DIG1_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define EX_DIG1_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define EX_DIG1_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define EX_DIG1_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define EX_DIG1_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define EX_DIG1_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 aliases
#define EX_DIG2_TRIS                 TRISCbits.TRISC1
#define EX_DIG2_LAT                  LATCbits.LATC1
#define EX_DIG2_PORT                 PORTCbits.RC1
#define EX_DIG2_WPU                  WPUCbits.WPUC1
#define EX_DIG2_OD                   ODCONCbits.ODCC1
#define EX_DIG2_ANS                  ANSELCbits.ANSELC1
#define EX_DIG2_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define EX_DIG2_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define EX_DIG2_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define EX_DIG2_GetValue()           PORTCbits.RC1
#define EX_DIG2_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define EX_DIG2_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define EX_DIG2_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define EX_DIG2_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define EX_DIG2_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define EX_DIG2_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define EX_DIG2_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define EX_DIG2_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC2 aliases
#define ADC_PULSE_TRIS                 TRISCbits.TRISC2
#define ADC_PULSE_LAT                  LATCbits.LATC2
#define ADC_PULSE_PORT                 PORTCbits.RC2
#define ADC_PULSE_WPU                  WPUCbits.WPUC2
#define ADC_PULSE_OD                   ODCONCbits.ODCC2
#define ADC_PULSE_ANS                  ANSELCbits.ANSELC2
#define ADC_PULSE_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define ADC_PULSE_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define ADC_PULSE_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define ADC_PULSE_GetValue()           PORTCbits.RC2
#define ADC_PULSE_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define ADC_PULSE_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define ADC_PULSE_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define ADC_PULSE_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define ADC_PULSE_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define ADC_PULSE_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define ADC_PULSE_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define ADC_PULSE_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define ADC_PRESSURE_TRIS                 TRISCbits.TRISC3
#define ADC_PRESSURE_LAT                  LATCbits.LATC3
#define ADC_PRESSURE_PORT                 PORTCbits.RC3
#define ADC_PRESSURE_WPU                  WPUCbits.WPUC3
#define ADC_PRESSURE_OD                   ODCONCbits.ODCC3
#define ADC_PRESSURE_ANS                  ANSELCbits.ANSELC3
#define ADC_PRESSURE_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define ADC_PRESSURE_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define ADC_PRESSURE_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define ADC_PRESSURE_GetValue()           PORTCbits.RC3
#define ADC_PRESSURE_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define ADC_PRESSURE_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define ADC_PRESSURE_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define ADC_PRESSURE_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define ADC_PRESSURE_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define ADC_PRESSURE_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define ADC_PRESSURE_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define ADC_PRESSURE_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define SW2_ACTION_TRIS                 TRISCbits.TRISC4
#define SW2_ACTION_LAT                  LATCbits.LATC4
#define SW2_ACTION_PORT                 PORTCbits.RC4
#define SW2_ACTION_WPU                  WPUCbits.WPUC4
#define SW2_ACTION_OD                   ODCONCbits.ODCC4
#define SW2_ACTION_ANS                  ANSELCbits.ANSELC4
#define SW2_ACTION_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define SW2_ACTION_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define SW2_ACTION_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define SW2_ACTION_GetValue()           PORTCbits.RC4
#define SW2_ACTION_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define SW2_ACTION_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define SW2_ACTION_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define SW2_ACTION_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define SW2_ACTION_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define SW2_ACTION_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define SW2_ACTION_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define SW2_ACTION_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC7 aliases
#define IO_RC7_TRIS                 TRISCbits.TRISC7
#define IO_RC7_LAT                  LATCbits.LATC7
#define IO_RC7_PORT                 PORTCbits.RC7
#define IO_RC7_WPU                  WPUCbits.WPUC7
#define IO_RC7_OD                   ODCONCbits.ODCC7
#define IO_RC7_ANS                  ANSELCbits.ANSELC7
#define IO_RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define IO_RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define IO_RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define IO_RC7_GetValue()           PORTCbits.RC7
#define IO_RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define IO_RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define IO_RC7_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define IO_RC7_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define IO_RC7_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define IO_RC7_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define IO_RC7_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define IO_RC7_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD5 aliases
#define LCD_RS_TRIS                 TRISDbits.TRISD5
#define LCD_RS_LAT                  LATDbits.LATD5
#define LCD_RS_PORT                 PORTDbits.RD5
#define LCD_RS_WPU                  WPUDbits.WPUD5
#define LCD_RS_OD                   ODCONDbits.ODCD5
#define LCD_RS_ANS                  ANSELDbits.ANSELD5
#define LCD_RS_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define LCD_RS_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define LCD_RS_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define LCD_RS_GetValue()           PORTDbits.RD5
#define LCD_RS_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define LCD_RS_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define LCD_RS_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define LCD_RS_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define LCD_RS_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define LCD_RS_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define LCD_RS_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define LCD_RS_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RD6 aliases
#define LCD_VO_TRIS                 TRISDbits.TRISD6
#define LCD_VO_LAT                  LATDbits.LATD6
#define LCD_VO_PORT                 PORTDbits.RD6
#define LCD_VO_WPU                  WPUDbits.WPUD6
#define LCD_VO_OD                   ODCONDbits.ODCD6
#define LCD_VO_ANS                  ANSELDbits.ANSELD6
#define LCD_VO_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define LCD_VO_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define LCD_VO_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define LCD_VO_GetValue()           PORTDbits.RD6
#define LCD_VO_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define LCD_VO_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define LCD_VO_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define LCD_VO_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define LCD_VO_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define LCD_VO_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define LCD_VO_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define LCD_VO_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RE0 aliases
#define EX_DIG3_TRIS                 TRISEbits.TRISE0
#define EX_DIG3_LAT                  LATEbits.LATE0
#define EX_DIG3_PORT                 PORTEbits.RE0
#define EX_DIG3_WPU                  WPUEbits.WPUE0
#define EX_DIG3_OD                   ODCONEbits.ODCE0
#define EX_DIG3_ANS                  ANSELEbits.ANSELE0
#define EX_DIG3_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define EX_DIG3_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define EX_DIG3_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define EX_DIG3_GetValue()           PORTEbits.RE0
#define EX_DIG3_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define EX_DIG3_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define EX_DIG3_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define EX_DIG3_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define EX_DIG3_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define EX_DIG3_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define EX_DIG3_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define EX_DIG3_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RE1 aliases
#define EX_DIG4_TRIS                 TRISEbits.TRISE1
#define EX_DIG4_LAT                  LATEbits.LATE1
#define EX_DIG4_PORT                 PORTEbits.RE1
#define EX_DIG4_WPU                  WPUEbits.WPUE1
#define EX_DIG4_OD                   ODCONEbits.ODCE1
#define EX_DIG4_ANS                  ANSELEbits.ANSELE1
#define EX_DIG4_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define EX_DIG4_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define EX_DIG4_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define EX_DIG4_GetValue()           PORTEbits.RE1
#define EX_DIG4_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define EX_DIG4_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define EX_DIG4_SetPullup()          do { WPUEbits.WPUE1 = 1; } while(0)
#define EX_DIG4_ResetPullup()        do { WPUEbits.WPUE1 = 0; } while(0)
#define EX_DIG4_SetPushPull()        do { ODCONEbits.ODCE1 = 0; } while(0)
#define EX_DIG4_SetOpenDrain()       do { ODCONEbits.ODCE1 = 1; } while(0)
#define EX_DIG4_SetAnalogMode()      do { ANSELEbits.ANSELE1 = 1; } while(0)
#define EX_DIG4_SetDigitalMode()     do { ANSELEbits.ANSELE1 = 0; } while(0)

// get/set RF0 aliases
#define IO_RF0_TRIS                 TRISFbits.TRISF0
#define IO_RF0_LAT                  LATFbits.LATF0
#define IO_RF0_PORT                 PORTFbits.RF0
#define IO_RF0_WPU                  WPUFbits.WPUF0
#define IO_RF0_OD                   ODCONFbits.ODCF0
#define IO_RF0_ANS                  ANSELFbits.ANSELF0
#define IO_RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_RF0_GetValue()           PORTFbits.RF0
#define IO_RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF3 aliases
#define EX_DIG5_TRIS                 TRISFbits.TRISF3
#define EX_DIG5_LAT                  LATFbits.LATF3
#define EX_DIG5_PORT                 PORTFbits.RF3
#define EX_DIG5_WPU                  WPUFbits.WPUF3
#define EX_DIG5_OD                   ODCONFbits.ODCF3
#define EX_DIG5_ANS                  ANSELFbits.ANSELF3
#define EX_DIG5_SetHigh()            do { LATFbits.LATF3 = 1; } while(0)
#define EX_DIG5_SetLow()             do { LATFbits.LATF3 = 0; } while(0)
#define EX_DIG5_Toggle()             do { LATFbits.LATF3 = ~LATFbits.LATF3; } while(0)
#define EX_DIG5_GetValue()           PORTFbits.RF3
#define EX_DIG5_SetDigitalInput()    do { TRISFbits.TRISF3 = 1; } while(0)
#define EX_DIG5_SetDigitalOutput()   do { TRISFbits.TRISF3 = 0; } while(0)
#define EX_DIG5_SetPullup()          do { WPUFbits.WPUF3 = 1; } while(0)
#define EX_DIG5_ResetPullup()        do { WPUFbits.WPUF3 = 0; } while(0)
#define EX_DIG5_SetPushPull()        do { ODCONFbits.ODCF3 = 0; } while(0)
#define EX_DIG5_SetOpenDrain()       do { ODCONFbits.ODCF3 = 1; } while(0)
#define EX_DIG5_SetAnalogMode()      do { ANSELFbits.ANSELF3 = 1; } while(0)
#define EX_DIG5_SetDigitalMode()     do { ANSELFbits.ANSELF3 = 0; } while(0)

// get/set RF4 aliases
#define LCD_DB7_TRIS                 TRISFbits.TRISF4
#define LCD_DB7_LAT                  LATFbits.LATF4
#define LCD_DB7_PORT                 PORTFbits.RF4
#define LCD_DB7_WPU                  WPUFbits.WPUF4
#define LCD_DB7_OD                   ODCONFbits.ODCF4
#define LCD_DB7_ANS                  ANSELFbits.ANSELF4
#define LCD_DB7_SetHigh()            do { LATFbits.LATF4 = 1; } while(0)
#define LCD_DB7_SetLow()             do { LATFbits.LATF4 = 0; } while(0)
#define LCD_DB7_Toggle()             do { LATFbits.LATF4 = ~LATFbits.LATF4; } while(0)
#define LCD_DB7_GetValue()           PORTFbits.RF4
#define LCD_DB7_SetDigitalInput()    do { TRISFbits.TRISF4 = 1; } while(0)
#define LCD_DB7_SetDigitalOutput()   do { TRISFbits.TRISF4 = 0; } while(0)
#define LCD_DB7_SetPullup()          do { WPUFbits.WPUF4 = 1; } while(0)
#define LCD_DB7_ResetPullup()        do { WPUFbits.WPUF4 = 0; } while(0)
#define LCD_DB7_SetPushPull()        do { ODCONFbits.ODCF4 = 0; } while(0)
#define LCD_DB7_SetOpenDrain()       do { ODCONFbits.ODCF4 = 1; } while(0)
#define LCD_DB7_SetAnalogMode()      do { ANSELFbits.ANSELF4 = 1; } while(0)
#define LCD_DB7_SetDigitalMode()     do { ANSELFbits.ANSELF4 = 0; } while(0)

// get/set RF5 aliases
#define LCD_DB6_TRIS                 TRISFbits.TRISF5
#define LCD_DB6_LAT                  LATFbits.LATF5
#define LCD_DB6_PORT                 PORTFbits.RF5
#define LCD_DB6_WPU                  WPUFbits.WPUF5
#define LCD_DB6_OD                   ODCONFbits.ODCF5
#define LCD_DB6_ANS                  ANSELFbits.ANSELF5
#define LCD_DB6_SetHigh()            do { LATFbits.LATF5 = 1; } while(0)
#define LCD_DB6_SetLow()             do { LATFbits.LATF5 = 0; } while(0)
#define LCD_DB6_Toggle()             do { LATFbits.LATF5 = ~LATFbits.LATF5; } while(0)
#define LCD_DB6_GetValue()           PORTFbits.RF5
#define LCD_DB6_SetDigitalInput()    do { TRISFbits.TRISF5 = 1; } while(0)
#define LCD_DB6_SetDigitalOutput()   do { TRISFbits.TRISF5 = 0; } while(0)
#define LCD_DB6_SetPullup()          do { WPUFbits.WPUF5 = 1; } while(0)
#define LCD_DB6_ResetPullup()        do { WPUFbits.WPUF5 = 0; } while(0)
#define LCD_DB6_SetPushPull()        do { ODCONFbits.ODCF5 = 0; } while(0)
#define LCD_DB6_SetOpenDrain()       do { ODCONFbits.ODCF5 = 1; } while(0)
#define LCD_DB6_SetAnalogMode()      do { ANSELFbits.ANSELF5 = 1; } while(0)
#define LCD_DB6_SetDigitalMode()     do { ANSELFbits.ANSELF5 = 0; } while(0)

// get/set RF6 aliases
#define LCD_DB5_TRIS                 TRISFbits.TRISF6
#define LCD_DB5_LAT                  LATFbits.LATF6
#define LCD_DB5_PORT                 PORTFbits.RF6
#define LCD_DB5_WPU                  WPUFbits.WPUF6
#define LCD_DB5_OD                   ODCONFbits.ODCF6
#define LCD_DB5_ANS                  ANSELFbits.ANSELF6
#define LCD_DB5_SetHigh()            do { LATFbits.LATF6 = 1; } while(0)
#define LCD_DB5_SetLow()             do { LATFbits.LATF6 = 0; } while(0)
#define LCD_DB5_Toggle()             do { LATFbits.LATF6 = ~LATFbits.LATF6; } while(0)
#define LCD_DB5_GetValue()           PORTFbits.RF6
#define LCD_DB5_SetDigitalInput()    do { TRISFbits.TRISF6 = 1; } while(0)
#define LCD_DB5_SetDigitalOutput()   do { TRISFbits.TRISF6 = 0; } while(0)
#define LCD_DB5_SetPullup()          do { WPUFbits.WPUF6 = 1; } while(0)
#define LCD_DB5_ResetPullup()        do { WPUFbits.WPUF6 = 0; } while(0)
#define LCD_DB5_SetPushPull()        do { ODCONFbits.ODCF6 = 0; } while(0)
#define LCD_DB5_SetOpenDrain()       do { ODCONFbits.ODCF6 = 1; } while(0)
#define LCD_DB5_SetAnalogMode()      do { ANSELFbits.ANSELF6 = 1; } while(0)
#define LCD_DB5_SetDigitalMode()     do { ANSELFbits.ANSELF6 = 0; } while(0)

// get/set RF7 aliases
#define LCD_DB4_TRIS                 TRISFbits.TRISF7
#define LCD_DB4_LAT                  LATFbits.LATF7
#define LCD_DB4_PORT                 PORTFbits.RF7
#define LCD_DB4_WPU                  WPUFbits.WPUF7
#define LCD_DB4_OD                   ODCONFbits.ODCF7
#define LCD_DB4_ANS                  ANSELFbits.ANSELF7
#define LCD_DB4_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define LCD_DB4_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define LCD_DB4_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define LCD_DB4_GetValue()           PORTFbits.RF7
#define LCD_DB4_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define LCD_DB4_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define LCD_DB4_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define LCD_DB4_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define LCD_DB4_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define LCD_DB4_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define LCD_DB4_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define LCD_DB4_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/