# /// script
# requires-python = ">=3.12"
# dependencies = [
#   "pyserial",
#   "matplotlib",
# ]
# ///

import csv

import matplotlib.pyplot as plt
import serial

PORT = "/dev/ttyACM0"   # Update to match your Curiosity Nano serial port
BAUD = 115200
OUT_CSV = "bp_capture.csv"

rows = []
header = None

with serial.Serial(PORT, BAUD, timeout=2.0) as ser:
    print(f"Listening on {PORT} @ {BAUD} baud... Run a BP measurement on the board.")
    while True:
        line = ser.readline().decode("utf-8", errors="ignore").strip()
        if not line:
            continue
        if line.startswith("tick_10ms,"):
            header = line.split(",")
            rows = []
            print("Receiving CSV header...")
        elif line == "---END_TELEM---":
            print(f"Captured {len(rows)} samples.")
            break
        elif header is not None:
            parts = line.split(",")
            if len(parts) == len(header):
                rows.append([int(x) for x in parts])

with open(OUT_CSV, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

print(f"Saved {OUT_CSV}")

# Plot cuff pressure (mmHg) and AC pulse waveform (ADC counts)
t_sec = [r[0] * 0.01 for r in rows]
cuff_mmhg = [r[1] for r in rows]
raw_ac = [r[3] for r in rows]

fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(9, 6))
ax1.plot(t_sec, cuff_mmhg, color="tab:blue")
ax1.set_ylabel("Cuff Pressure (mmHg)")
ax1.set_title("EGR 304 Cuff Deflation & Oscillometric Pulse Capture")
ax1.grid(True)

ax2.plot(t_sec, raw_ac, color="tab:red")
ax2.set_ylabel("Pulse ADC (0-4095)")
ax2.set_xlabel("Time (s)")
ax2.grid(True)

plt.tight_layout()
plt.savefig("bp_waveforms.png", dpi=150)
plt.show()