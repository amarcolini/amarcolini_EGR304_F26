include("${CMAKE_CURRENT_LIST_DIR}/rule.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/file.cmake")

set(BloodPressure_default_library_list )

set(OUTPUT_SUFFIX elf)
# Handle files with suffix (s|as|asm|AS|ASM|As|aS|Asm), for group default-XC8
if(BloodPressure_default_default_XC8_FILE_TYPE_assemble)
add_library(BloodPressure_default_default_XC8_assemble OBJECT ${BloodPressure_default_default_XC8_FILE_TYPE_assemble})
    BloodPressure_default_default_XC8_assemble_rule(BloodPressure_default_default_XC8_assemble)
    list(APPEND BloodPressure_default_library_list "$<TARGET_OBJECTS:BloodPressure_default_default_XC8_assemble>")

endif()

# Handle files with suffix S, for group default-XC8
if(BloodPressure_default_default_XC8_FILE_TYPE_assemblePreprocess)
add_library(BloodPressure_default_default_XC8_assemblePreprocess OBJECT ${BloodPressure_default_default_XC8_FILE_TYPE_assemblePreprocess})
    BloodPressure_default_default_XC8_assemblePreprocess_rule(BloodPressure_default_default_XC8_assemblePreprocess)
    list(APPEND BloodPressure_default_library_list "$<TARGET_OBJECTS:BloodPressure_default_default_XC8_assemblePreprocess>")

endif()

# Handle files with suffix [cC], for group default-XC8
if(BloodPressure_default_default_XC8_FILE_TYPE_compile)
add_library(BloodPressure_default_default_XC8_compile OBJECT ${BloodPressure_default_default_XC8_FILE_TYPE_compile})
    BloodPressure_default_default_XC8_compile_rule(BloodPressure_default_default_XC8_compile)
    list(APPEND BloodPressure_default_library_list "$<TARGET_OBJECTS:BloodPressure_default_default_XC8_compile>")

endif()

# Handle files with suffix elf, for group default-XC8
if(BloodPressure_default_default_XC8_FILE_TYPE_objcopy_lss)
add_library(BloodPressure_default_default_XC8_objcopy_lss OBJECT ${BloodPressure_default_default_XC8_FILE_TYPE_objcopy_lss})
    BloodPressure_default_default_XC8_objcopy_lss_rule(BloodPressure_default_default_XC8_objcopy_lss)
    list(APPEND BloodPressure_default_library_list "$<TARGET_OBJECTS:BloodPressure_default_default_XC8_objcopy_lss>")

endif()


# Main target for this project
add_executable(BloodPressure_default_image_Aa1oFdou ${BloodPressure_default_library_list})

set_target_properties(BloodPressure_default_image_Aa1oFdou PROPERTIES
    OUTPUT_NAME "default"
    SUFFIX ".elf"
    ADDITIONAL_CLEAN_FILES "${output_extensions}"
    RUNTIME_OUTPUT_DIRECTORY "${BloodPressure_default_output_dir}")
target_link_libraries(BloodPressure_default_image_Aa1oFdou PRIVATE ${BloodPressure_default_default_XC8_FILE_TYPE_link})
# Add the link options from the rule file.
BloodPressure_default_link_rule( BloodPressure_default_image_Aa1oFdou)


#Add objcopy steps
BloodPressure_default_objcopy_lss_rule(BloodPressure_default_image_Aa1oFdou)

